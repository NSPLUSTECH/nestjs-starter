import { AppController } from "./app.controller";

export default [
    AppController
];