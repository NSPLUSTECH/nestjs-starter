import { UserService } from "./User.Service";

export default [
    UserService
];