import { User } from "./User.entity";

export default [
    User
]